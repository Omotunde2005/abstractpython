# About

An unofficial python wrapper for [AbstractAPI](https://www.abstractapi.com/). Python developers can now use AbstractAPI without having to remember all endpoints. It also does type validation before requests are sent to the API server.


## Disclaimer

This is not an official library by the team @AbstractAPI. This should not be considered as a direct replacement of AbstractAPI API suites. Rather, it is a bunch of helper classes that python developers can use to communicate easier with any of the APIs. 